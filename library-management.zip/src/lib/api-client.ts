/**
 * Standalone replacement for the workspace-only `@workspace/api-client-react`
 * package (which was auto-generated from an OpenAPI spec inside the original
 * monorepo and isn't publishable on its own).
 *
 * This file re-implements every hook the app imports from that package,
 * using TanStack Query + fetch against the bundled Express API in /server.
 * Call signatures match what the pages already expect, so no page code
 * needed to change.
 */
import { useMutation, useQuery, useQueryClient, type UseMutationResult, type UseQueryResult } from "@tanstack/react-query";
import { AUTH_CONFIG } from "@/lib/config";

// ---------------------------------------------------------------------------
// Low-level fetch helpers
// ---------------------------------------------------------------------------

function getToken(): string | null {
  return localStorage.getItem(AUTH_CONFIG.TOKEN_KEY) || sessionStorage.getItem(AUTH_CONFIG.TOKEN_KEY);
}

function buildQuery(params?: Record<string, any>): string {
  if (!params) return "";
  const usp = new URLSearchParams();
  Object.entries(params).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") {
      usp.append(key, String(value));
    }
  });
  const qs = usp.toString();
  return qs ? `?${qs}` : "";
}

async function request<T = any>(method: string, path: string, body?: any): Promise<T> {
  const token = getToken();
  const res = await fetch(path, {
    method,
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body !== undefined ? JSON.stringify(body) : undefined,
  });

  const text = await res.text();
  let data: any = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = text;
    }
  }

  if (!res.ok) {
    const message = (data && (data.error || data.message)) || res.statusText || "Request failed";
    const err: any = new Error(message);
    err.response = { status: res.status, data };
    throw err;
  }

  return data as T;
}

const apiGet = <T = any>(path: string, params?: Record<string, any>) => request<T>("GET", `${path}${buildQuery(params)}`);
const apiPost = <T = any>(path: string, body?: any) => request<T>("POST", path, body);
const apiPut = <T = any>(path: string, body?: any) => request<T>("PUT", path, body);
const apiDelete = <T = any>(path: string) => request<T>("DELETE", path);

// ---------------------------------------------------------------------------
// Query key helpers (exported so pages can invalidate consistently)
// ---------------------------------------------------------------------------

export const getGetDashboardStatsQueryKey = () => ["dashboard", "stats"] as const;
export const getListBooksQueryKey = (params?: Record<string, any>) => ["books", "list", params ?? {}] as const;
export const getGetBookQueryKey = (id: number) => ["books", "detail", id] as const;
export const getListMembersQueryKey = (params?: Record<string, any>) => ["members", "list", params ?? {}] as const;
export const getGetMemberQueryKey = (id: number) => ["members", "detail", id] as const;
export const getGetMemberBorrowingsQueryKey = (id: number) => ["members", id, "borrowings"] as const;
export const getListBorrowingsQueryKey = (params?: Record<string, any>) => ["borrowings", "list", params ?? {}] as const;

type QueryOptions = { query?: { enabled?: boolean } };

// ---------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------

export function useGetDashboardStats(): UseQueryResult<any> {
  return useQuery({
    queryKey: getGetDashboardStatsQueryKey(),
    queryFn: () => apiGet("/api/dashboard/stats"),
  });
}

export function useGetPopularBooks(params: { limit?: number } = {}): UseQueryResult<any[]> {
  return useQuery({
    queryKey: ["dashboard", "popular-books", params],
    queryFn: () => apiGet("/api/dashboard/popular-books", params),
  });
}

export function useGetOverdueBorrowings(): UseQueryResult<any[]> {
  return useQuery({
    queryKey: ["dashboard", "overdue"],
    queryFn: () => apiGet("/api/dashboard/overdue"),
  });
}

export function useGetRecentActivity(params: { limit?: number } = {}): UseQueryResult<any[]> {
  return useQuery({
    queryKey: ["dashboard", "recent-activity", params],
    queryFn: () => apiGet("/api/dashboard/recent-activity", params),
  });
}

// ---------------------------------------------------------------------------
// Books
// ---------------------------------------------------------------------------

export function useListBooks(params: { search?: string; genre?: string; available?: boolean } = {}): UseQueryResult<any[]> {
  return useQuery({
    queryKey: getListBooksQueryKey(params),
    queryFn: () => apiGet("/api/books", params),
  });
}

export function useCreateBook(): UseMutationResult<any, any, { data: any }> {
  return useMutation({
    mutationFn: ({ data }) => apiPost("/api/books", data),
  });
}

export function useGetBook(id: number, options?: QueryOptions): UseQueryResult<any> {
  return useQuery({
    queryKey: getGetBookQueryKey(id),
    queryFn: () => apiGet(`/api/books/${id}`),
    enabled: options?.query?.enabled ?? true,
  });
}

export function useUpdateBook(): UseMutationResult<any, any, { id: number; data: any }> {
  return useMutation({
    mutationFn: ({ id, data }) => apiPut(`/api/books/${id}`, data),
  });
}

export function useDeleteBook(): UseMutationResult<any, any, { id: number }> {
  return useMutation({
    mutationFn: ({ id }) => apiDelete(`/api/books/${id}`),
  });
}

// ---------------------------------------------------------------------------
// Members
// ---------------------------------------------------------------------------

export function useListMembers(params: { search?: string; status?: string; membershipType?: string } = {}): UseQueryResult<any[]> {
  return useQuery({
    queryKey: getListMembersQueryKey(params),
    queryFn: () => apiGet("/api/members", params),
  });
}

export function useCreateMember(): UseMutationResult<any, any, { data: any }> {
  return useMutation({
    mutationFn: ({ data }) => apiPost("/api/members", data),
  });
}

export function useGetMember(id: number, options?: QueryOptions): UseQueryResult<any> {
  return useQuery({
    queryKey: getGetMemberQueryKey(id),
    queryFn: () => apiGet(`/api/members/${id}`),
    enabled: options?.query?.enabled ?? true,
  });
}

export function useUpdateMember(): UseMutationResult<any, any, { id: number; data: any }> {
  return useMutation({
    mutationFn: ({ id, data }) => apiPut(`/api/members/${id}`, data),
  });
}

export function useDeleteMember(): UseMutationResult<any, any, { id: number }> {
  return useMutation({
    mutationFn: ({ id }) => apiDelete(`/api/members/${id}`),
  });
}

export function useGetMemberBorrowings(id: number, options?: QueryOptions): UseQueryResult<any[]> {
  return useQuery({
    queryKey: getGetMemberBorrowingsQueryKey(id),
    queryFn: () => apiGet(`/api/members/${id}/borrowings`),
    enabled: options?.query?.enabled ?? true,
  });
}

// ---------------------------------------------------------------------------
// Borrowings
// ---------------------------------------------------------------------------

export function useListBorrowings(params: { bookId?: number; status?: string } = {}, options?: QueryOptions): UseQueryResult<any[]> {
  return useQuery({
    queryKey: getListBorrowingsQueryKey(params),
    queryFn: () => apiGet("/api/borrowings", params),
    enabled: options?.query?.enabled ?? true,
  });
}

export function useIssueBorrowing(): UseMutationResult<any, any, { data: any }> {
  return useMutation({
    mutationFn: ({ data }) => apiPost("/api/borrowings", data),
  });
}

export function useReturnBorrowing(): UseMutationResult<any, any, { id: number }> {
  return useMutation({
    mutationFn: ({ id }) => apiPost(`/api/borrowings/${id}/return`, {}),
  });
}

export function useWaiveFine(): UseMutationResult<any, any, { id: number }> {
  return useMutation({
    mutationFn: ({ id }) => apiPost(`/api/borrowings/${id}/waive-fine`, {}),
  });
}

// Re-export for convenience in case any future code wants the raw client.
export { apiGet, apiPost, apiPut, apiDelete };
